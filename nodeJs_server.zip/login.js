//开发者信息
const APPID = 'wx91f0b611d8a7a22d'
const APPSECRET = '7ad273269c7fd1ee872d3c9210e72b9d'
const JWTSECRET = 'smartFeeding'

//导入包
const request = require('request');
const express = require('express');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const User = require('./models/User');
const bodyParser = require('body-parser');

const router = express.Router();
const login = router;

// 连接本地MongoDB数据库
mongoose.connect('mongodb://localhost:27017/userInfo',{
  useNewUrlParser: true,
  useUnifiedTopology: true,
})


//定义login路由
router.post('/',bodyParser.urlencoded({ extended:true }),(req, res)=>{
  const code = req.body.code;
  // 构造请求体
  const options = {
    url:'https://api.weixin.qq.com/sns/jscode2session',
    qs:{
      appid:APPID,
      secret:APPSECRET,
      js_code:code,
      grant_type:'authorization_code'
    }
  };

  // 发送请求到微信接口获取session_key和openid
  request(options,(error,response,body)=>{
    if(error){
      console.log(error);
      return res.status(500).send('request error!');
    }
    // 分割请求体获得session_key和openid
    const { session_key, openid } = JSON.parse(body);
    if(!session_key || !openid){
      console.log(body);
      return res.status(500).send('login error!');
    }
    // 生成token返回给小程序
    const token = jwt.sign({ openid },JWTSECRET,{ expiresIn:'7d' })
    // console.log('session_key:',session_key,'openid:',openid);
    // console.log('token:',token);
    res.send({ session_key, openid, token })

    // 将用户信息存入数据库
    const user = new User({
      token,
      openid,
      session_key,
      petUrl:'',
      petName:'',
      petBirthday:'',
    });

    user.save()
      .then(saveUser =>{
        console.log('User saved:',saveUser);
      })
      .catch(err=>{
        console.error('Error saving user:',err);
      })
  })
});

//导出模块
module.exports = login;
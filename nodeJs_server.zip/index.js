//导入包
const express = require('express')
const bodyParser = require('body-parser')
const loginRouter = require('./login')
const checkLoginRouter = require('./checklogin')
const uploadRouter = require('./upload')
const petInfoRouter = require('./petinfo')
const getPetInfoRouter = require('./getpetinfo')

const path = require('path')
const app = express()
const PORT = 3000

//调用中间件
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
app.use('/login',loginRouter)
app.use('/checklogin',checkLoginRouter)
app.use('/uploads',express.static(path.join(__dirname,'uploads')))
app.use('/upload',uploadRouter)
app.use('/petinfo',petInfoRouter)	
app.use('/getpetinfo',getPetInfoRouter)

//监听3000端口
app.listen(PORT,()=>{
	console.log(`server running at port ${PORT}`);
})


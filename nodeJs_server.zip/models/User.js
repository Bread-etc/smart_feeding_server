const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    token: { type: String, required: true },
    openid: { type:String, required: true , unique: true},
    session_key: { type:String, required: true },
    petUrl: { type:String, default: "" },
    petName: { type:String, default: "" },
    petBirthday: { type:Date, default: "" },
});

const User = mongoose.model('User', userSchema)

module.exports = User
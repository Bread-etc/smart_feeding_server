// 导入包
const express = require('express');
const router = express.Router();
const checklogin = router;
const jwt = require('jsonwebtoken');
const JWTSECRET = 'smartFeeding'
const User = require('./models/User');
const bodyParser = require('body-parser');

// 创建checklogin路由
router.post('/',bodyParser.urlencoded({ extended:true }) , async(req,res)=>{
  const token = req.body.token;
  if(!token){
    return res.status(401).send({ message:'Token not provided.'});
  }
  try{
    const decoded = jwt.verify(token,JWTSECRET);
    const user = await User.findOne({ openid: decoded.openid });
    if(!user){
      // 重定向到login模块
      return res.redirect('/login');
    }
    if(user.token !== token){
      // 更新数据库中的token
      user.token = token;
      await user.save();
    }
    res.send({ is_login:true });
  } catch(err){
    console.error(err);
    res.status(401).send({ message:'Invalid token.'})
  }
})

// 导出模块
module.exports = checklogin;
// 导入包
const express = require('express');
const multer = require('multer');
const User = require('./models/User');
const router  = express.Router();

// Multer存储配置
const storage = multer.diskStorage({
    destination:(req,file,cb)=>{
        cb(null,'./uploads');
    },
    filename:(req,file,cb)=>{
        cb(null,Date.now() + '-' + file.originalname); 
    }
});
const upload = multer({ storage: storage });

// 处理上传图片路由
router.post('/', upload.single('file'), async(req,res)=>{
    const openid = req.body.openid;
    const petUrl = 'http://localhost:3000/uploads/' + req.file.filename;
    User.findOneAndUpdate({ openid:openid }, { petUrl:petUrl }, { new:true })
        .then(user => {
            res.status(200).json(user);
        })
        .catch(err =>{
            console.log(err);
            res.status(500).send('Internal Server Error')
        })
});

module.exports = router
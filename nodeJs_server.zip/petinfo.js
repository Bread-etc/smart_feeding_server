// 导入包
const express = require('express')
const router = express.Router()
const User = require('./models/User')

router.post('/',async (req,res)=>{
    const openid = req.body.openid.toString();

    try{
        const user = await User.findOne({ openid: openid }).exec();
        if(!user){
            res.status(404).json({ message:'User not found' });
            return;
        }

        const petInfo = {
            petName: user.petName,
            petBirthday: user.petBirthday, // 只保留年月日
        };
        // 覆盖用户之前的信息
        user.petName = req.body.petName;
        user.petBirthday = req.body.petBirthday;
        await user.save();

        res.status(200).json(petInfo);
    } catch(error) {
        console.error(error);
        res.status(500).send('Internal Server Error');
    }
});

module.exports = router